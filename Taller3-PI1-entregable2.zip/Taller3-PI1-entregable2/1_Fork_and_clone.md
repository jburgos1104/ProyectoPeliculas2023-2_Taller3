## Fork y clone

Haga un fork del proyecto, seleccionando la opción ``Fork``.
<div align="center">
  <a>
    <img src="imgs/fork1a.png">
  </a>
</div>

Seleccione el botón ``Create fork``.
<div align="center">
  <a>
    <img src="imgs/fork2a.png">
  </a>
</div>

Copie el enlace del git del repositorio, seleccionando el botón ``< > Code``, y luego, la opción ``copiar``.
<div align="center">
  <a>
    <img src="imgs/fork3a.png">
  </a>
</div>

Clone el repositorio en la máquina local, para esto ubíquese en la carpeta (local) en la que quedará almacenado el proyecto. Luego, use la instrucción ``git clone`` seguida del enlace git que acaba de copiar.
<div align="center">
  <a>
    <img src="imgs/fork4.png">
  </a>
</div>
